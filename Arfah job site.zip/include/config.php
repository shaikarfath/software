<?php

const BASE_URL = "http://test.test/fyp/admin/";
const APP_NAME = "Job Portal";
include "db.php";
$db = new db();
date_default_timezone_set("Asia/Karachi");

?>
